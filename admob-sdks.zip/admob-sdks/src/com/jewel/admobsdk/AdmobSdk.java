package com.jewel.admobsdk;

import java.util.List;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;

import android.content.Context;

public class AdmobSdk extends AndroidNonvisibleComponent {
    private final Context context;

    public AdmobSdk(ComponentContainer container) {
        super(container.$form());
        context = (Context) container.$context();
    }

    @SimpleFunction(description = "Initialize the sdk before load any admob or ad manager ads.")
    public void Initialize() {
        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
                Initialized();
            }
        });
    }

    @SimpleEvent(description = "The admob sdk is initialized.")
    public void Initialized() {
        EventDispatcher.dispatchEvent(this, "Initialized", new Object[0]);
    }

    @SimpleProperty(description = "Tag for child directed treatment can either be 0, 1 or -1. \n"
            + "You can find more in developers.google.com/admob/android/targeting\n"
            + "TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE == 1\n"
            + "TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE == 0\n" + "TAG_FOR_CHILD_DIRECTED_TREATMENT_UNSPECIFIED == -1")
    public void TagForChildDirectedTreatment(int value) {
        if (value == 0 || value == 1 || value == -1) {
            RequestConfiguration requestConfiguration = MobileAds.getRequestConfiguration()
                    .toBuilder()
                    .setTagForChildDirectedTreatment(value)
                    .build();
            MobileAds.setRequestConfiguration(requestConfiguration);
        } else {
            Failed("Value for TagForChildDirectedTreatment can either be 1,0 or -1. Read Documentation Carefully");
        }
    }

    @SimpleProperty(description = "TAG_FOR_UNDER_AGE_OF_CONSENT_TRUE == 1\n"
            + "TAG_FOR_UNDER_AGE_OF_CONSENT_FALSE == 0\n" + "TAG_FOR_UNDER_AGE_OF_CONSENT_UNSPECIFIED == -1")
    public void TagForUnderAgeOfConsent(int value) {
        if (value == 0 || value == 1 || value == -1) {
            RequestConfiguration requestConfiguration = MobileAds.getRequestConfiguration()
                    .toBuilder()
                    .setTagForUnderAgeOfConsent(value)
                    .build();
            MobileAds.setRequestConfiguration(requestConfiguration);
        } else {
            Failed("Value for TagForUnderAgeOfConsent can either be 1,0 or -1. Read Documentation Carefully");
        }
    }

    @SimpleProperty(description = "Value can either be G, MA, PG, or T.\n"
            + "Content that are suitable for general audiences, including families can be G.\n"
            + "Content that are suitable for only matured audiences can be MA.\n"
            + "Content that are suitable for most audiences with parental guidance can be PG.\n"
            + "Content that are suitable for teen and older audiences can be T")
    public void MaxAdContentRating(String value) {
        String upperCaseValue = value.toUpperCase();
        if (upperCaseValue.equals("G") || upperCaseValue.equals("MA") || upperCaseValue.equals("PG")
                || upperCaseValue.equals("T")) {
            RequestConfiguration requestConfiguration = MobileAds.getRequestConfiguration()
                    .toBuilder()
                    .setMaxAdContentRating(upperCaseValue)
                    .build();
            MobileAds.setRequestConfiguration(requestConfiguration);
        } else {
            Failed("Value for MaxAdContentRating can either be G,MA,PG or T. Read Documentation Carefully");
        }
    }

    @SimpleProperty(description = "Set device ids list to set mutliple device id.")
    public void TestDevice(List<String> deviceIds) {
        RequestConfiguration requestConfiguration = MobileAds.getRequestConfiguration()
                .toBuilder().setTestDeviceIds(deviceIds).build();
        MobileAds.setRequestConfiguration(requestConfiguration);
    }

    @SimpleEvent(description = "Something went error while using extension properties.")
    public void Failed(String error) {
        EventDispatcher.dispatchEvent(this, "Failed", error);
    }
}
